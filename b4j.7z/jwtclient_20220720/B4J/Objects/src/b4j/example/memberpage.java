package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class memberpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.memberpage", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.memberpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4j.example.customlistview _clvdata = null;
public b4j.example.preferencesdialog _prefdialog = null;
public b4j.example.ddd _dd = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_no = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_name = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_password = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_memo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbledit = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbldelete = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _label1 = null;
public b4j.example.b4xloadingindicator _indloading = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.function01 _function01 = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public void  _adddata() throws Exception{
ResumableSub_AddData rsub = new ResumableSub_AddData(this);
rsub.resume(ba, null);
}
public static class ResumableSub_AddData extends BA.ResumableSub {
public ResumableSub_AddData(b4j.example.memberpage parent) {
this.parent = parent;
}
b4j.example.memberpage parent;
anywheresoftware.b4a.objects.collections.Map _item = null;
int _result = 0;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4j.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4j.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 220;BA.debugLine="Dim Item As Map = CreateMap()";
_item = new anywheresoftware.b4a.objects.collections.Map();
_item = parent.__c.createMap(new Object[] {});
 //BA.debugLineNum = 222;BA.debugLine="PrefDialog.Title = \"會員資料-新增\"";
parent._prefdialog._settitle /*Object*/ ((Object)("會員資料-新增"));
 //BA.debugLineNum = 223;BA.debugLine="PrefDialog.LoadFromJson(File.ReadString(File.DirA";
parent._prefdialog._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"template.json"));
 //BA.debugLineNum = 225;BA.debugLine="Wait For (PrefDialog.ShowDialog(Item, \"OK\", \"CANC";
parent.__c.WaitFor("complete", ba, this, parent._prefdialog._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_item,(Object)("OK"),(Object)("CANCEL")));
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result = (int) result[0];
;
 //BA.debugLineNum = 226;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 228;BA.debugLine="Log(\"遠端新增...\")";
parent.__c.LogImpl("746727178","遠端新增...",0);
 //BA.debugLineNum = 229;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 230;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 231;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 234;BA.debugLine="basicAuth = Main.token";
_basicauth = parent._main._token /*String*/ ;
 //BA.debugLineNum = 235;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"U";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 237;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicA";
parent.__c.LogImpl("746727187",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 239;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 240;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 241;BA.debugLine="m1.Put(\"action\",\"insert\")";
_m1.Put((Object)("action"),(Object)("insert"));
 //BA.debugLineNum = 242;BA.debugLine="m1.Put(\"mem_no\",Item.Get(\"mem_no\"))";
_m1.Put((Object)("mem_no"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 243;BA.debugLine="m1.Put(\"mem_name\",Item.Get(\"mem_name\"))";
_m1.Put((Object)("mem_name"),_item.Get((Object)("mem_name")));
 //BA.debugLineNum = 244;BA.debugLine="m1.Put(\"mem_password\",Item.Get(\"mem_password\"))";
_m1.Put((Object)("mem_password"),_item.Get((Object)("mem_password")));
 //BA.debugLineNum = 245;BA.debugLine="m1.Put(\"mem_memo\",Item.Get(\"mem_memo\"))";
_m1.Put((Object)("mem_memo"),_item.Get((Object)("mem_memo")));
 //BA.debugLineNum = 247;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 248;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 249;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 251;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 252;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_mem";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 253;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 254;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 256;BA.debugLine="Function01.ProgressShow(indLoading,\"\")";
parent._function01._progressshow /*String*/ (parent._indloading,"");
 //BA.debugLineNum = 257;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 18;
return;
case 18:
//C
this.state = 4;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 258;BA.debugLine="Function01.ProgressHide(indLoading)";
parent._function01._progresshide /*String*/ (parent._indloading);
 //BA.debugLineNum = 259;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("746727209","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 260;BA.debugLine="If job.Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_job._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 261;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("746727211","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 262;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4j.objects.collections.JSONParser();
 //BA.debugLineNum = 263;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 264;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 265;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 266;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("746727216",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 268;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 270;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 272;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("746727222",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 275;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("746727225",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 276;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,_job._errormessage /*String*/ ,"Error");
 //BA.debugLineNum = 278;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 283;BA.debugLine="Log(\"本地新增...\")";
parent.__c.LogImpl("746727233","本地新增...",0);
 //BA.debugLineNum = 284;BA.debugLine="Dim p As B4XView = CreateCard(m1)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._createcard(_m1);
 //BA.debugLineNum = 285;BA.debugLine="clvData.Add(p, m1)";
parent._clvdata._add(_p,(Object)(_m1.getObject()));
 //BA.debugLineNum = 287;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,"新增成功!!");
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 290;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public void  _jobdone(b4j.example.httpjob _job) throws Exception{
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 30;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 34;BA.debugLine="dd.Initialize";
_dd._initialize /*String*/ (ba);
 //BA.debugLineNum = 35;BA.debugLine="xui.RegisterDesignerClass(dd)";
_xui.RegisterDesignerClass((Object)(_dd));
 //BA.debugLineNum = 41;BA.debugLine="Root.LoadLayout(\"MemberPage\")";
_root.LoadLayout("MemberPage",ba);
 //BA.debugLineNum = 42;BA.debugLine="B4XPages.SetTitle(Me, \"會員資料\")";
_b4xpages._settitle /*String*/ (this,(Object)("會員資料"));
 //BA.debugLineNum = 56;BA.debugLine="PrefDialog.Initialize(Root, \"編輯\", 300dip , 400dip";
_prefdialog._initialize /*String*/ (ba,_root,(Object)("編輯"),__c.DipToCurrent((int) (300)),__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 60;BA.debugLine="PrefDialog.SetEventsListener(Me, \"PrefDialog\")";
_prefdialog._seteventslistener /*String*/ (this,"PrefDialog");
 //BA.debugLineNum = 64;BA.debugLine="QueryData";
_querydata();
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_menuclick(String _tag) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Sub B4XPage_MenuClick (Tag As String)";
 //BA.debugLineNum = 77;BA.debugLine="Log(\"B4XPage_MenuClick==>\")";
__c.LogImpl("746530561","B4XPage_MenuClick==>",0);
 //BA.debugLineNum = 78;BA.debugLine="Log(Tag)";
__c.LogImpl("746530562",_tag,0);
 //BA.debugLineNum = 80;BA.debugLine="If Tag = \"新增\" Then";
if ((_tag).equals("新增")) { 
 //BA.debugLineNum = 81;BA.debugLine="Log(\"Add Event\")";
__c.LogImpl("746530565","Add Event",0);
 //BA.debugLineNum = 83;BA.debugLine="AddData";
_adddata();
 };
 //BA.debugLineNum = 85;BA.debugLine="If Tag = \"更新\" Then";
if ((_tag).equals("更新")) { 
 //BA.debugLineNum = 86;BA.debugLine="Log(\"Refresh Event\")";
__c.LogImpl("746530570","Refresh Event",0);
 //BA.debugLineNum = 88;BA.debugLine="QueryData";
_querydata();
 };
 //BA.debugLineNum = 90;BA.debugLine="If Tag = \"查詢\" Then";
if ((_tag).equals("查詢")) { 
 //BA.debugLineNum = 91;BA.debugLine="Log(\"mnu2\")";
__c.LogImpl("746530575","mnu2",0);
 //BA.debugLineNum = 94;BA.debugLine="Function01.ShowToast ( B4XPages.MainPage.toast ,";
_function01._showtoast /*String*/ (_b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,_root,"mnu2");
 };
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Sub B4XPage_Resize (Width As Int, Height As Int)";
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 6;BA.debugLine="Private clvData As CustomListView";
_clvdata = new b4j.example.customlistview();
 //BA.debugLineNum = 7;BA.debugLine="Public PrefDialog As PreferencesDialog";
_prefdialog = new b4j.example.preferencesdialog();
 //BA.debugLineNum = 8;BA.debugLine="Private dd As DDD";
_dd = new b4j.example.ddd();
 //BA.debugLineNum = 11;BA.debugLine="Private lblMem_No As B4XView";
_lblmem_no = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private lblMem_Name As B4XView";
_lblmem_name = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private lblMem_Password As B4XView";
_lblmem_password = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private lblMem_Memo As B4XView";
_lblmem_memo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private lblEdit As B4XView";
_lbledit = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblDelete As B4XView";
_lbldelete = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private Label1 As B4XView";
_label1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private indLoading As B4XLoadingIndicator";
_indloading = new b4j.example.b4xloadingindicator();
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _createcard(anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int _height = 0;
 //BA.debugLineNum = 112;BA.debugLine="Sub CreateCard (Data As Map) As B4XView";
 //BA.debugLineNum = 113;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 114;BA.debugLine="Dim height As Int = 220dip";
_height = __c.DipToCurrent((int) (220));
 //BA.debugLineNum = 116;BA.debugLine="height = clvData.AsView.Height /3 -2dip";
_height = (int) (_clvdata._asview().getHeight()/(double)3-__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 124;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, clvData.AsView.Width";
_p.SetLayoutAnimated((int) (0),0,0,_clvdata._asview().getWidth(),_height);
 //BA.debugLineNum = 125;BA.debugLine="p.LoadLayout(\"Card\")";
_p.LoadLayout("Card",ba);
 //BA.debugLineNum = 128;BA.debugLine="lblMem_No.Text = Data.Get(\"mem_no\")";
_lblmem_no.setText(BA.ObjectToString(_data.Get((Object)("mem_no"))));
 //BA.debugLineNum = 129;BA.debugLine="lblMem_Name.Text = Data.Get(\"mem_name\")";
_lblmem_name.setText(BA.ObjectToString(_data.Get((Object)("mem_name"))));
 //BA.debugLineNum = 130;BA.debugLine="lblMem_Password.Text = Data.Get(\"mem_password\")";
_lblmem_password.setText(BA.ObjectToString(_data.Get((Object)("mem_password"))));
 //BA.debugLineNum = 131;BA.debugLine="lblMem_Memo.Text = Data.Get(\"mem_memo\")";
_lblmem_memo.setText(BA.ObjectToString(_data.Get((Object)("mem_memo"))));
 //BA.debugLineNum = 134;BA.debugLine="lblEdit.Tag = Data";
_lbledit.setTag((Object)(_data.getObject()));
 //BA.debugLineNum = 135;BA.debugLine="lblDelete.Tag = Data";
_lbldelete.setTag((Object)(_data.getObject()));
 //BA.debugLineNum = 136;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return null;
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public void  _lbldelete_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
ResumableSub_lblDelete_MouseClicked rsub = new ResumableSub_lblDelete_MouseClicked(this,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_lblDelete_MouseClicked extends BA.ResumableSub {
public ResumableSub_lblDelete_MouseClicked(b4j.example.memberpage parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.memberpage parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.objects.collections.Map _item = null;
Object _sf = null;
int _result = 0;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4j.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4j.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 409;BA.debugLine="Log(\"lblDelete_Click==>\")";
parent.__c.LogImpl("750659329","lblDelete_Click==>",0);
 //BA.debugLineNum = 411;BA.debugLine="Dim Index As Int = clvData.GetItemFromView(Sender";
_index = parent._clvdata._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba))));
 //BA.debugLineNum = 413;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 416;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 418;BA.debugLine="l = Sender";
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 419;BA.debugLine="Dim Item As Map";
_item = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 420;BA.debugLine="Item.Initialize";
_item.Initialize();
 //BA.debugLineNum = 422;BA.debugLine="Item = l.Tag";
_item = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_l.getTag()));
 //BA.debugLineNum = 425;BA.debugLine="Dim sf As Object = xui.Msgbox2Async($\"刪除會員: ${Ite";
_sf = parent._xui.Msgbox2Async(ba,("刪除會員: "+parent.__c.SmartStringFormatter("",_item.Get((Object)("mem_name")))+"?"),"","Yes","","No",(javafx.scene.image.Image)(parent.__c.Null));
 //BA.debugLineNum = 427;BA.debugLine="Wait For (sf) Msgbox_Result (Result As Int)";
parent.__c.WaitFor("msgbox_result", ba, this, _sf);
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result = (int) result[0];
;
 //BA.debugLineNum = 428;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 430;BA.debugLine="Log(\"遠端刪除...\")";
parent.__c.LogImpl("750659350","遠端刪除...",0);
 //BA.debugLineNum = 431;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 432;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 433;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 436;BA.debugLine="basicAuth = Main.token";
_basicauth = parent._main._token /*String*/ ;
 //BA.debugLineNum = 437;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"U";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 439;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicA";
parent.__c.LogImpl("750659359",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 441;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 442;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 443;BA.debugLine="m1.Put(\"action\",\"delete\")";
_m1.Put((Object)("action"),(Object)("delete"));
 //BA.debugLineNum = 444;BA.debugLine="m1.Put(\"mem_no\",Item.Get(\"mem_no\"))";
_m1.Put((Object)("mem_no"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 446;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 447;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 448;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 450;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 451;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_mem";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 452;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 453;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 455;BA.debugLine="Function01.ProgressShow(indLoading,\"\")";
parent._function01._progressshow /*String*/ (parent._indloading,"");
 //BA.debugLineNum = 456;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 18;
return;
case 18:
//C
this.state = 4;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 457;BA.debugLine="Function01.ProgressHide(indLoading)";
parent._function01._progresshide /*String*/ (parent._indloading);
 //BA.debugLineNum = 458;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("750659378","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 459;BA.debugLine="If job.Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_job._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 460;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("750659380","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 461;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4j.objects.collections.JSONParser();
 //BA.debugLineNum = 462;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 463;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 464;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 465;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("750659385",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 466;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 468;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 470;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("750659390",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 473;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("750659393",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 474;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,_job._errormessage /*String*/ ,"Error");
 //BA.debugLineNum = 476;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 479;BA.debugLine="Log(\"本地刪除...\")";
parent.__c.LogImpl("750659399","本地刪除...",0);
 //BA.debugLineNum = 480;BA.debugLine="clvData.RemoveAt(Index)";
parent._clvdata._removeat(_index);
 //BA.debugLineNum = 481;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,"刪除成功!!");
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 486;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _msgbox_result(int _result) throws Exception{
}
public void  _lbledit_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
ResumableSub_lblEdit_MouseClicked rsub = new ResumableSub_lblEdit_MouseClicked(this,_eventdata);
rsub.resume(ba, null);
}
public static class ResumableSub_lblEdit_MouseClicked extends BA.ResumableSub {
public ResumableSub_lblEdit_MouseClicked(b4j.example.memberpage parent,anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) {
this.parent = parent;
this._eventdata = _eventdata;
}
b4j.example.memberpage parent;
anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.objects.collections.Map _item = null;
int _result = 0;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4j.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4j.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 295;BA.debugLine="Log(\"lblEdit_Click==>\")";
parent.__c.LogImpl("750593793","lblEdit_Click==>",0);
 //BA.debugLineNum = 300;BA.debugLine="Dim Index As Int = clvData.GetItemFromView(Sender";
_index = parent._clvdata._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba))));
 //BA.debugLineNum = 301;BA.debugLine="Dim pnl As B4XView = clvData.GetPanel(Index)";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = parent._clvdata._getpanel(_index);
 //BA.debugLineNum = 302;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 304;BA.debugLine="l = Sender";
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 305;BA.debugLine="Dim Item As Map";
_item = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 306;BA.debugLine="Item.Initialize";
_item.Initialize();
 //BA.debugLineNum = 307;BA.debugLine="Item = l.Tag";
_item = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_l.getTag()));
 //BA.debugLineNum = 308;BA.debugLine="Item.Put(\"mem_oldno\",Item.Get(\"mem_no\"))";
_item.Put((Object)("mem_oldno"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 310;BA.debugLine="PrefDialog.Title = \"會員資料-修改\"";
parent._prefdialog._settitle /*Object*/ ((Object)("會員資料-修改"));
 //BA.debugLineNum = 311;BA.debugLine="PrefDialog.LoadFromJson(File.ReadString(File.DirA";
parent._prefdialog._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"template.json"));
 //BA.debugLineNum = 313;BA.debugLine="Wait For (PrefDialog.ShowDialog(Item, \"OK\", \"CANC";
parent.__c.WaitFor("complete", ba, this, parent._prefdialog._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_item,(Object)("OK"),(Object)("CANCEL")));
this.state = 27;
return;
case 27:
//C
this.state = 1;
_result = (int) result[0];
;
 //BA.debugLineNum = 314;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 26;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 315;BA.debugLine="Log(\"遠端修改...\")";
parent.__c.LogImpl("750593813","遠端修改...",0);
 //BA.debugLineNum = 316;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 317;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 318;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 321;BA.debugLine="basicAuth =  Main.token";
_basicauth = parent._main._token /*String*/ ;
 //BA.debugLineNum = 322;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"U";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 324;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicA";
parent.__c.LogImpl("750593822",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 326;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 327;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 328;BA.debugLine="m1.Put(\"action\",\"update\")";
_m1.Put((Object)("action"),(Object)("update"));
 //BA.debugLineNum = 329;BA.debugLine="m1.Put(\"mem_no\",Item.Get(\"mem_no\"))";
_m1.Put((Object)("mem_no"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 330;BA.debugLine="m1.Put(\"mem_name\",Item.Get(\"mem_name\"))";
_m1.Put((Object)("mem_name"),_item.Get((Object)("mem_name")));
 //BA.debugLineNum = 331;BA.debugLine="m1.Put(\"mem_password\",Item.Get(\"mem_password\"))";
_m1.Put((Object)("mem_password"),_item.Get((Object)("mem_password")));
 //BA.debugLineNum = 332;BA.debugLine="m1.Put(\"mem_memo\",Item.Get(\"mem_memo\"))";
_m1.Put((Object)("mem_memo"),_item.Get((Object)("mem_memo")));
 //BA.debugLineNum = 333;BA.debugLine="m1.Put(\"mem_oldno\",Item.Get(\"mem_oldno\"))";
_m1.Put((Object)("mem_oldno"),_item.Get((Object)("mem_oldno")));
 //BA.debugLineNum = 335;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 336;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 337;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 339;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 340;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_mem";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 341;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 342;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 344;BA.debugLine="Function01.ProgressShow(indLoading,\"\")";
parent._function01._progressshow /*String*/ (parent._indloading,"");
 //BA.debugLineNum = 345;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 28;
return;
case 28:
//C
this.state = 4;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 346;BA.debugLine="Function01.ProgressHide(indLoading)";
parent._function01._progresshide /*String*/ (parent._indloading);
 //BA.debugLineNum = 347;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("750593845","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 348;BA.debugLine="If job.Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_job._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 349;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("750593847","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 350;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4j.objects.collections.JSONParser();
 //BA.debugLineNum = 351;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 352;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 353;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 354;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("750593852",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 355;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 357;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 359;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("750593857",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 362;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("750593860",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 363;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,_job._errormessage /*String*/ ,"Error");
 //BA.debugLineNum = 365;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 368;BA.debugLine="Log(\"本地修改...\")";
parent.__c.LogImpl("750593866","本地修改...",0);
 //BA.debugLineNum = 377;BA.debugLine="If pnl.NumberOfViews > 0 Then";
if (true) break;

case 16:
//if
this.state = 25;
if (_pnl.getNumberOfViews()>0) { 
this.state = 18;
}if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 384;BA.debugLine="Try";
if (true) break;

case 19:
//try
this.state = 24;
this.catchState = 23;
this.state = 21;
if (true) break;

case 21:
//C
this.state = 24;
this.catchState = 23;
 //BA.debugLineNum = 385;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_no\").Text = m1.G";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_no").setText(BA.ObjectToString(_m1.Get((Object)("mem_no"))));
 //BA.debugLineNum = 386;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_name\").Text = m1";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_name").setText(BA.ObjectToString(_m1.Get((Object)("mem_name"))));
 //BA.debugLineNum = 387;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_password\").Text";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_password").setText(BA.ObjectToString(_m1.Get((Object)("mem_password"))));
 //BA.debugLineNum = 388;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_memo\").Text = m1";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_memo").setText(BA.ObjectToString(_m1.Get((Object)("mem_memo"))));
 //BA.debugLineNum = 390;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,"修改成功!!");
 if (true) break;

case 23:
//C
this.state = 24;
this.catchState = 0;
 //BA.debugLineNum = 392;BA.debugLine="Log(\"err: \"&LastException)";
parent.__c.LogImpl("750593890","err: "+BA.ObjectToString(parent.__c.LastException(ba)),0);
 //BA.debugLineNum = 393;BA.debugLine="xui.MsgboxAsync(LastException, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToString(parent.__c.LastException(ba)),"Error");
 if (true) break;
if (true) break;

case 24:
//C
this.state = 25;
this.catchState = 0;
;
 if (true) break;

case 25:
//C
this.state = 26;
;
 if (true) break;

case 26:
//C
this.state = -1;
;
 //BA.debugLineNum = 404;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public String  _menubar1_action() throws Exception{
anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper _mi = null;
String _t = "";
 //BA.debugLineNum = 102;BA.debugLine="Sub MenuBar1_Action";
 //BA.debugLineNum = 103;BA.debugLine="Dim mi As MenuItem = Sender";
_mi = new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper();
_mi = (anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.objects.MenuItemWrapper.ConcreteMenuItemWrapper(), (javafx.scene.control.MenuItem)(__c.Sender(ba)));
 //BA.debugLineNum = 104;BA.debugLine="Dim t As String";
_t = "";
 //BA.debugLineNum = 105;BA.debugLine="If mi.Tag = Null Then t = mi.Text.Replace(\"_\", \"\"";
if (_mi.getTag()== null) { 
_t = _mi.getText().replace("_","");}
else {
_t = BA.ObjectToString(_mi.getTag());};
 //BA.debugLineNum = 106;BA.debugLine="B4XPage_MenuClick(t)";
_b4xpage_menuclick(_t);
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public void  _querydata() throws Exception{
ResumableSub_QueryData rsub = new ResumableSub_QueryData(this);
rsub.resume(ba, null);
}
public static class ResumableSub_QueryData extends BA.ResumableSub {
public ResumableSub_QueryData(b4j.example.memberpage parent) {
this.parent = parent;
}
b4j.example.memberpage parent;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4j.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4j.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.collections.List _udata = null;
int _u = 0;
anywheresoftware.b4a.objects.collections.Map _mdata = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int step39;
int limit39;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 141;BA.debugLine="clvData.Clear";
parent._clvdata._clear();
 //BA.debugLineNum = 144;BA.debugLine="Log(\"查詢....\")";
parent.__c.LogImpl("746661637","查詢....",0);
 //BA.debugLineNum = 145;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 146;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 147;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 149;BA.debugLine="basicAuth = Main.token";
_basicauth = parent._main._token /*String*/ ;
 //BA.debugLineNum = 150;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"UT";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 152;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicAu";
parent.__c.LogImpl("746661645",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 154;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 156;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 157;BA.debugLine="m1.Put(\"action\",\"query\")";
_m1.Put((Object)("action"),(Object)("query"));
 //BA.debugLineNum = 158;BA.debugLine="m1.Put(\"mem_no\",\"\")";
_m1.Put((Object)("mem_no"),(Object)(""));
 //BA.debugLineNum = 159;BA.debugLine="m1.Put(\"mem_name\",\"\")";
_m1.Put((Object)("mem_name"),(Object)(""));
 //BA.debugLineNum = 161;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4j.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 163;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 164;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 166;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 167;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_memb";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 168;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Bearer";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 169;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www-";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 171;BA.debugLine="Function01.ProgressShow(indLoading,\"\")";
parent._function01._progressshow /*String*/ (parent._indloading,"");
 //BA.debugLineNum = 172;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 17;
return;
case 17:
//C
this.state = 1;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 173;BA.debugLine="Function01.ProgressHide(indLoading)";
parent._function01._progresshide /*String*/ (parent._indloading);
 //BA.debugLineNum = 174;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("746661667","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 175;BA.debugLine="If job.Success Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_job._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 15;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 176;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("746661669","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 177;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4j.objects.collections.JSONParser();
 //BA.debugLineNum = 178;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 179;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 181;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 4:
//if
this.state = 13;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 13;
 //BA.debugLineNum = 182;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("746661675",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 183;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 185;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 187;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("746661680",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 189;BA.debugLine="Dim udata As List";
_udata = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 190;BA.debugLine="udata.Initialize";
_udata.Initialize();
 //BA.debugLineNum = 191;BA.debugLine="udata = m.Get(\"udata\")";
_udata = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_m.Get((Object)("udata"))));
 //BA.debugLineNum = 193;BA.debugLine="For u=0 To udata.Size -1";
if (true) break;

case 9:
//for
this.state = 12;
step39 = 1;
limit39 = (int) (_udata.getSize()-1);
_u = (int) (0) ;
this.state = 18;
if (true) break;

case 18:
//C
this.state = 12;
if ((step39 > 0 && _u <= limit39) || (step39 < 0 && _u >= limit39)) this.state = 11;
if (true) break;

case 19:
//C
this.state = 18;
_u = ((int)(0 + _u + step39)) ;
if (true) break;

case 11:
//C
this.state = 19;
 //BA.debugLineNum = 194;BA.debugLine="Dim mdata As Map";
_mdata = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 195;BA.debugLine="mdata.Initialize";
_mdata.Initialize();
 //BA.debugLineNum = 196;BA.debugLine="mdata = udata.Get(u)";
_mdata = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_udata.Get(_u)));
 //BA.debugLineNum = 198;BA.debugLine="Dim p As B4XView = CreateCard(mdata)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._createcard(_mdata);
 //BA.debugLineNum = 199;BA.debugLine="clvData.Add(p, mdata)";
parent._clvdata._add(_p,(Object)(_mdata.getObject()));
 //BA.debugLineNum = 201;BA.debugLine="Log(\"u= \"&u)";
parent.__c.LogImpl("746661694","u= "+BA.NumberToString(_u),0);
 if (true) break;
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 204;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (parent._b4xpages._mainpage /*b4j.example.b4xmainpage*/ ()._toast /*b4j.example.bctoast*/ ,parent._root,"查詢完畢!!");
 if (true) break;

case 13:
//C
this.state = 16;
;
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 208;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("746661701",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 209;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,_job._errormessage /*String*/ ,"Error");
 //BA.debugLineNum = 211;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 214;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
