package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class homepage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.homepage", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.homepage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4j.example.b4xdrawer _drawer = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _hamburgericon = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _label1 = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.function01 _function01 = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_appear() throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Private Sub B4XPage_Appear";
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _b4xpage_closerequest() throws Exception{
ResumableSub_B4XPage_CloseRequest rsub = new ResumableSub_B4XPage_CloseRequest(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_B4XPage_CloseRequest extends BA.ResumableSub {
public ResumableSub_B4XPage_CloseRequest(b4j.example.homepage parent) {
this.parent = parent;
}
b4j.example.homepage parent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 72;BA.debugLine="Return True";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
anywheresoftware.b4j.objects.ImageViewWrapper _iv = null;
 //BA.debugLineNum = 18;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 19;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 22;BA.debugLine="B4XPages.SetTitle(Me, \"首頁\")";
_b4xpages._settitle /*String*/ (this,(Object)("首頁"));
 //BA.debugLineNum = 24;BA.debugLine="Drawer.Initialize(Me, \"Drawer\", Root, 200dip)";
_drawer._initialize /*String*/ (ba,this,"Drawer",_root,__c.DipToCurrent((int) (200)));
 //BA.debugLineNum = 25;BA.debugLine="Drawer.CenterPanel.LoadLayout(\"HomePage\")";
_drawer._getcenterpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().LoadLayout("HomePage",ba);
 //BA.debugLineNum = 26;BA.debugLine="Drawer.LeftPanel.LoadLayout(\"Page2Left\")";
_drawer._getleftpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().LoadLayout("Page2Left",ba);
 //BA.debugLineNum = 28;BA.debugLine="HamburgerIcon = xui.LoadBitmapResize(File.DirAsse";
_hamburgericon = _xui.LoadBitmapResize(__c.File.getDirAssets(),"hamburger.png",__c.DipToCurrent((int) (32)),__c.DipToCurrent((int) (32)),__c.True);
 //BA.debugLineNum = 36;BA.debugLine="Dim iv As ImageView";
_iv = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="iv.Initialize(\"imgHamburger\")";
_iv.Initialize(ba,"imgHamburger");
 //BA.debugLineNum = 38;BA.debugLine="iv.SetImage(HamburgerIcon)";
_iv.SetImage((javafx.scene.image.Image)(_hamburgericon.getObject()));
 //BA.debugLineNum = 39;BA.debugLine="Drawer.CenterPanel.AddView(iv, 2dip, 2dip, 32dip,";
_drawer._getcenterpanel /*anywheresoftware.b4a.objects.B4XViewWrapper*/ ().AddView((javafx.scene.Node)(_iv.getObject()),__c.DipToCurrent((int) (2)),__c.DipToCurrent((int) (2)),__c.DipToCurrent((int) (32)),__c.DipToCurrent((int) (32)));
 //BA.debugLineNum = 40;BA.debugLine="iv.PickOnBounds = True";
_iv.setPickOnBounds(__c.True);
 //BA.debugLineNum = 43;BA.debugLine="Label1.Text = \"歡迎~~~\" & Main.mem_no";
_label1.setText("歡迎~~~"+_main._mem_no /*String*/ );
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_disappear() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Private Sub B4XPage_Disappear";
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Private Sub B4XPage_Resize (Width As Int, Height A";
 //BA.debugLineNum = 94;BA.debugLine="Drawer.Resize(Width, Height)";
_drawer._resize /*String*/ (_width,_height);
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public String  _btnmember_click() throws Exception{
 //BA.debugLineNum = 111;BA.debugLine="Private Sub btnMember_Click";
 //BA.debugLineNum = 113;BA.debugLine="Drawer.LeftOpen = False";
_drawer._setleftopen /*boolean*/ (__c.False);
 //BA.debugLineNum = 116;BA.debugLine="B4XPages.ShowPage(\"MemberPage\")";
_b4xpages._showpage /*String*/ ("MemberPage");
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public String  _btnsignout_click() throws Exception{
 //BA.debugLineNum = 102;BA.debugLine="Sub btnSignOut_Click";
 //BA.debugLineNum = 104;BA.debugLine="Drawer.LeftOpen = False";
_drawer._setleftopen /*boolean*/ (__c.False);
 //BA.debugLineNum = 107;BA.debugLine="B4XPages.ShowPageAndRemovePreviousPages(\"MainPage";
_b4xpages._showpageandremovepreviouspages /*String*/ ("MainPage");
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return "";
}
public String  _button1_click() throws Exception{
 //BA.debugLineNum = 119;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 121;BA.debugLine="B4XPages.ShowPage(\"MemberPage\")";
_b4xpages._showpage /*String*/ ("MemberPage");
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 6;BA.debugLine="Private Drawer As B4XDrawer";
_drawer = new b4j.example.b4xdrawer();
 //BA.debugLineNum = 7;BA.debugLine="Private HamburgerIcon As B4XBitmap";
_hamburgericon = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private Label1 As B4XView";
_label1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _imghamburger_mouseclicked(anywheresoftware.b4j.objects.NodeWrapper.MouseEventWrapper _eventdata) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub imgHamburger_MouseClicked (EventData As MouseE";
 //BA.debugLineNum = 49;BA.debugLine="Drawer.LeftOpen = True";
_drawer._setleftopen /*boolean*/ (__c.True);
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 14;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
