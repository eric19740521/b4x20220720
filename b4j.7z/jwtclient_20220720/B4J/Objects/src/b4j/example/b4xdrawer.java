package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class b4xdrawer extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.b4xdrawer", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.b4xdrawer.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _meventname = "";
public Object _mcallback = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public int _msidewidth = 0;
public anywheresoftware.b4a.objects.B4XViewWrapper _mleftpanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mdarkpanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mbasepanel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _mcenterpanel = null;
public int _extrawidth = 0;
public float _touchxstart = 0f;
public float _touchystart = 0f;
public boolean _isopen = false;
public boolean _handlingswipe = false;
public boolean _startatscrim = false;
public boolean _menabled = false;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.function01 _function01 = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _changeoffset(float _x,boolean _currentlytouching,boolean _noanimation) throws Exception{
int _visibleoffset = 0;
int _dx = 0;
int _duration = 0;
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 175;BA.debugLine="Private Sub ChangeOffset (x As Float, CurrentlyTou";
 //BA.debugLineNum = 176;BA.debugLine="x = Max(-mSideWidth, Min(0, x))";
_x = (float) (__c.Max(-_msidewidth,__c.Min(0,_x)));
 //BA.debugLineNum = 177;BA.debugLine="Dim VisibleOffset As Int = mSideWidth + x";
_visibleoffset = (int) (_msidewidth+_x);
 //BA.debugLineNum = 186;BA.debugLine="If CurrentlyTouching = False Then";
if (_currentlytouching==__c.False) { 
 //BA.debugLineNum = 187;BA.debugLine="If (IsOpen And VisibleOffset < 0.8 * mSideWidth)";
if ((_isopen && _visibleoffset<0.8*_msidewidth) || (_isopen==__c.False && _visibleoffset<0.2*_msidewidth)) { 
 //BA.debugLineNum = 188;BA.debugLine="x = -mSideWidth";
_x = (float) (-_msidewidth);
 //BA.debugLineNum = 189;BA.debugLine="SetIsOpen(False)";
_setisopen(__c.False);
 }else {
 //BA.debugLineNum = 191;BA.debugLine="x = 0";
_x = (float) (0);
 //BA.debugLineNum = 192;BA.debugLine="SetIsOpen(True)";
_setisopen(__c.True);
 };
 //BA.debugLineNum = 194;BA.debugLine="Dim dx As Int = Abs(mLeftPanel.Left - x)";
_dx = (int) (__c.Abs(_mleftpanel.getLeft()-_x));
 //BA.debugLineNum = 195;BA.debugLine="Dim duration As Int = Max(0, 200 * dx / mSideWid";
_duration = (int) (__c.Max(0,200*_dx/(double)_msidewidth));
 //BA.debugLineNum = 196;BA.debugLine="If NoAnimation Then duration = 0";
if (_noanimation) { 
_duration = (int) (0);};
 //BA.debugLineNum = 197;BA.debugLine="mLeftPanel.SetLayoutAnimated(duration, x, 0, mLe";
_mleftpanel.SetLayoutAnimated(_duration,_x,0,_mleftpanel.getWidth(),_mleftpanel.getHeight());
 //BA.debugLineNum = 198;BA.debugLine="mDarkPanel.SetColorAnimated(duration, mDarkPanel";
_mdarkpanel.SetColorAnimated(_duration,_mdarkpanel.getColor(),_offsettocolor((int) (_x)));
 //BA.debugLineNum = 204;BA.debugLine="Private jo = mDarkPanel As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_mdarkpanel.getObject()));
 //BA.debugLineNum = 205;BA.debugLine="jo.RunMethod(\"setMouseTransparent\", Array(Not(Is";
_jo.RunMethod("setMouseTransparent",new Object[]{(Object)(__c.Not(_isopen))});
 }else {
 //BA.debugLineNum = 208;BA.debugLine="mDarkPanel.Color = OffsetToColor(x)";
_mdarkpanel.setColor(_offsettocolor((int) (_x)));
 //BA.debugLineNum = 209;BA.debugLine="mLeftPanel.Left = x";
_mleftpanel.setLeft(_x);
 };
 //BA.debugLineNum = 211;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private mEventName As String 'ignore";
_meventname = "";
 //BA.debugLineNum = 4;BA.debugLine="Private mCallBack As Object 'ignore";
_mcallback = new Object();
 //BA.debugLineNum = 5;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 6;BA.debugLine="Private mSideWidth As Int";
_msidewidth = 0;
 //BA.debugLineNum = 7;BA.debugLine="Private mLeftPanel As B4XView";
_mleftpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Private mDarkPanel As B4XView";
_mdarkpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private mBasePanel As B4XView";
_mbasepanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private mCenterPanel As B4XView";
_mcenterpanel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Public ExtraWidth As Int = 50dip";
_extrawidth = __c.DipToCurrent((int) (50));
 //BA.debugLineNum = 12;BA.debugLine="Private TouchXStart, TouchYStart As Float 'ignore";
_touchxstart = 0f;
_touchystart = 0f;
 //BA.debugLineNum = 13;BA.debugLine="Private IsOpen As Boolean";
_isopen = false;
 //BA.debugLineNum = 14;BA.debugLine="Private HandlingSwipe As Boolean";
_handlingswipe = false;
 //BA.debugLineNum = 15;BA.debugLine="Private StartAtScrim As Boolean 'ignore";
_startatscrim = false;
 //BA.debugLineNum = 16;BA.debugLine="Private mEnabled As Boolean = True";
_menabled = __c.True;
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _dark_touch(int _action,float _x,float _y) throws Exception{
 //BA.debugLineNum = 167;BA.debugLine="Private Sub Dark_Touch(Action As Int, X As Float,";
 //BA.debugLineNum = 168;BA.debugLine="If HandlingSwipe = False And Action = mDarkPanel.";
if (_handlingswipe==__c.False && _action==_mdarkpanel.TOUCH_ACTION_UP) { 
 //BA.debugLineNum = 169;BA.debugLine="setLeftOpen(False)";
_setleftopen(__c.False);
 };
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getcenterpanel() throws Exception{
 //BA.debugLineNum = 241;BA.debugLine="Public Sub getCenterPanel As B4XView";
 //BA.debugLineNum = 242;BA.debugLine="Return mCenterPanel";
if (true) return _mcenterpanel;
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
return null;
}
public boolean  _getgestureenabled() throws Exception{
 //BA.debugLineNum = 253;BA.debugLine="Public Sub getGestureEnabled As Boolean";
 //BA.debugLineNum = 254;BA.debugLine="Return mEnabled";
if (true) return _menabled;
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return false;
}
public boolean  _getleftopen() throws Exception{
 //BA.debugLineNum = 226;BA.debugLine="Public Sub getLeftOpen As Boolean";
 //BA.debugLineNum = 227;BA.debugLine="Return IsOpen";
if (true) return _isopen;
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return false;
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _getleftpanel() throws Exception{
 //BA.debugLineNum = 237;BA.debugLine="Public Sub getLeftPanel As B4XView";
 //BA.debugLineNum = 238;BA.debugLine="Return mLeftPanel";
if (true) return _mleftpanel;
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,Object _callback,String _eventname,anywheresoftware.b4a.objects.B4XViewWrapper _parent,int _sidewidth) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Initialize (Callback As Object, EventNa";
 //BA.debugLineNum = 20;BA.debugLine="mEventName = EventName";
_meventname = _eventname;
 //BA.debugLineNum = 21;BA.debugLine="mCallBack = Callback";
_mcallback = _callback;
 //BA.debugLineNum = 22;BA.debugLine="mSideWidth = SideWidth";
_msidewidth = _sidewidth;
 //BA.debugLineNum = 32;BA.debugLine="mBasePanel = xui.CreatePanel(\"\")";
_mbasepanel = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 34;BA.debugLine="Parent.AddView(mBasePanel, 0, 0, Parent.Width, Pa";
_parent.AddView((javafx.scene.Node)(_mbasepanel.getObject()),0,0,_parent.getWidth(),_parent.getHeight());
 //BA.debugLineNum = 35;BA.debugLine="mCenterPanel = xui.CreatePanel(\"\")";
_mcenterpanel = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 36;BA.debugLine="mBasePanel.AddView(mCenterPanel, 0, 0, mBasePanel";
_mbasepanel.AddView((javafx.scene.Node)(_mcenterpanel.getObject()),0,0,_mbasepanel.getWidth(),_mbasepanel.getHeight());
 //BA.debugLineNum = 37;BA.debugLine="mDarkPanel = xui.CreatePanel(\"dark\")";
_mdarkpanel = _xui.CreatePanel(ba,"dark");
 //BA.debugLineNum = 38;BA.debugLine="mBasePanel.AddView(mDarkPanel, 0, 0, mBasePanel.W";
_mbasepanel.AddView((javafx.scene.Node)(_mdarkpanel.getObject()),0,0,_mbasepanel.getWidth(),_mbasepanel.getHeight());
 //BA.debugLineNum = 39;BA.debugLine="mLeftPanel = xui.CreatePanel(\"LeftPanel\")";
_mleftpanel = _xui.CreatePanel(ba,"LeftPanel");
 //BA.debugLineNum = 40;BA.debugLine="mBasePanel.AddView(mLeftPanel, -SideWidth, 0, Sid";
_mbasepanel.AddView((javafx.scene.Node)(_mleftpanel.getObject()),-_sidewidth,0,_sidewidth,_mbasepanel.getHeight());
 //BA.debugLineNum = 41;BA.debugLine="mLeftPanel.Color = xui.Color_Red";
_mleftpanel.setColor(_xui.Color_Red);
 //BA.debugLineNum = 55;BA.debugLine="Private jo = mDarkPanel As JavaObject";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_mdarkpanel.getObject()));
 //BA.debugLineNum = 56;BA.debugLine="jo.RunMethod(\"setMouseTransparent\", Array(True))";
_jo.RunMethod("setMouseTransparent",new Object[]{(Object)(__c.True)});
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public String  _leftpanel_click() throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Private Sub LeftPanel_Click";
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return "";
}
public int  _offsettocolor(int _x) throws Exception{
float _visible = 0f;
 //BA.debugLineNum = 221;BA.debugLine="Private Sub OffsetToColor (x As Int) As Int";
 //BA.debugLineNum = 222;BA.debugLine="Dim Visible As Float = (mSideWidth + x) / mSideWi";
_visible = (float) ((_msidewidth+_x)/(double)_msidewidth);
 //BA.debugLineNum = 223;BA.debugLine="Return xui.Color_ARGB(100 * Visible, 0, 0, 0)";
if (true) return _xui.Color_ARGB((int) (100*_visible),(int) (0),(int) (0),(int) (0));
 //BA.debugLineNum = 224;BA.debugLine="End Sub";
return 0;
}
public String  _resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 245;BA.debugLine="Public Sub Resize(Width As Int, Height As Int)";
 //BA.debugLineNum = 246;BA.debugLine="If IsOpen Then ChangeOffset(-mSideWidth, False, T";
if (_isopen) { 
_changeoffset((float) (-_msidewidth),__c.False,__c.True);};
 //BA.debugLineNum = 247;BA.debugLine="mBasePanel.SetLayoutAnimated(0, 0, 0, Width, Heig";
_mbasepanel.SetLayoutAnimated((int) (0),0,0,_width,_height);
 //BA.debugLineNum = 248;BA.debugLine="mLeftPanel.SetLayoutAnimated(0, mLeftPanel.Left,";
_mleftpanel.SetLayoutAnimated((int) (0),_mleftpanel.getLeft(),0,_mleftpanel.getWidth(),_mbasepanel.getHeight());
 //BA.debugLineNum = 249;BA.debugLine="mDarkPanel.SetLayoutAnimated(0, 0, 0, Width, Heig";
_mdarkpanel.SetLayoutAnimated((int) (0),0,0,_width,_height);
 //BA.debugLineNum = 250;BA.debugLine="mCenterPanel.SetLayoutAnimated(0, 0, 0, Width, He";
_mcenterpanel.SetLayoutAnimated((int) (0),0,0,_width,_height);
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return "";
}
public String  _setgestureenabled(boolean _b) throws Exception{
 //BA.debugLineNum = 257;BA.debugLine="Public Sub setGestureEnabled (b As Boolean)";
 //BA.debugLineNum = 258;BA.debugLine="mEnabled = b";
_menabled = _b;
 //BA.debugLineNum = 259;BA.debugLine="End Sub";
return "";
}
public String  _setisopen(boolean _newstate) throws Exception{
 //BA.debugLineNum = 213;BA.debugLine="Private Sub SetIsOpen (NewState As Boolean)";
 //BA.debugLineNum = 214;BA.debugLine="If IsOpen = NewState Then Return";
if (_isopen==_newstate) { 
if (true) return "";};
 //BA.debugLineNum = 215;BA.debugLine="IsOpen = NewState";
_isopen = _newstate;
 //BA.debugLineNum = 216;BA.debugLine="If xui.SubExists(mCallBack, mEventName & \"_StateC";
if (_xui.SubExists(ba,_mcallback,_meventname+"_StateChanged",(int) (1))) { 
 //BA.debugLineNum = 217;BA.debugLine="CallSubDelayed2(mCallBack,  mEventName & \"_State";
__c.CallSubDelayed2(ba,_mcallback,_meventname+"_StateChanged",(Object)(_isopen));
 };
 //BA.debugLineNum = 219;BA.debugLine="End Sub";
return "";
}
public String  _setleftopen(boolean _b) throws Exception{
float _x = 0f;
 //BA.debugLineNum = 230;BA.debugLine="Public Sub setLeftOpen (b As Boolean)";
 //BA.debugLineNum = 231;BA.debugLine="If b = IsOpen Then Return";
if (_b==_isopen) { 
if (true) return "";};
 //BA.debugLineNum = 232;BA.debugLine="Dim x As Float";
_x = 0f;
 //BA.debugLineNum = 233;BA.debugLine="If b Then x = 0 Else x = -mSideWidth";
if (_b) { 
_x = (float) (0);}
else {
_x = (float) (-_msidewidth);};
 //BA.debugLineNum = 234;BA.debugLine="ChangeOffset(x, False, False)";
_changeoffset(_x,__c.False,__c.False);
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
