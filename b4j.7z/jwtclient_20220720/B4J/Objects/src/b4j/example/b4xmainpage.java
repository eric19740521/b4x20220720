package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.b4xmainpage", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4j.example.homepage _vhomepage = null;
public b4j.example.memberpage _vmemberpage = null;
public b4j.example.bctoast _toast = null;
public String _pluschar = "";
public anywheresoftware.b4a.objects.B4XViewWrapper _btnlogin = null;
public b4j.example.b4xfloattextfield _txtno = null;
public b4j.example.b4xfloattextfield _txtpassword = null;
public b4j.example.b4xloadingindicator _indloading = null;
public b4j.example.dateutils _dateutils = null;
public b4j.example.cssutils _cssutils = null;
public b4j.example.main _main = null;
public b4j.example.function01 _function01 = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public b4j.example.httputils2service _httputils2service = null;
public b4j.example.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_appear() throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub B4XPage_Appear";
 //BA.debugLineNum = 62;BA.debugLine="Function01.ProgressHide(indLoading)";
_function01._progresshide /*String*/ (_indloading);
 //BA.debugLineNum = 64;BA.debugLine="txtNo.Text = \"1\"";
_txtno._settext /*String*/ ("1");
 //BA.debugLineNum = 65;BA.debugLine="txtPassword.Text = \"1\"";
_txtpassword._settext /*String*/ ("1");
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 43;BA.debugLine="toast.Initialize(Root1)";
_toast._initialize /*String*/ (ba,_root1);
 //BA.debugLineNum = 45;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 46;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 48;BA.debugLine="B4XPages.SetTitle(Me, \"Login\")";
_b4xpages._settitle /*String*/ (this,(Object)("Login"));
 //BA.debugLineNum = 50;BA.debugLine="vHomePage.Initialize";
_vhomepage._initialize /*Object*/ (ba);
 //BA.debugLineNum = 51;BA.debugLine="B4XPages.AddPage(\"HomePage\", vHomePage)";
_b4xpages._addpage /*String*/ ("HomePage",(Object)(_vhomepage));
 //BA.debugLineNum = 52;BA.debugLine="vMemberPage.Initialize";
_vmemberpage._initialize /*Object*/ (ba);
 //BA.debugLineNum = 53;BA.debugLine="B4XPages.AddPage(\"MemberPage\", vMemberPage)";
_b4xpages._addpage /*String*/ ("MemberPage",(Object)(_vmemberpage));
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public void  _btnlogin_click() throws Exception{
ResumableSub_btnLogin_Click rsub = new ResumableSub_btnLogin_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btnLogin_Click extends BA.ResumableSub {
public ResumableSub_btnLogin_Click(b4j.example.b4xmainpage parent) {
this.parent = parent;
}
b4j.example.b4xmainpage parent;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
b4j.example.httpjob _job = null;
anywheresoftware.b4j.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 87;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 88;BA.debugLine="Dim basicAuth As String";
_basicauth = "";
 //BA.debugLineNum = 89;BA.debugLine="Dim job As HttpJob";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 91;BA.debugLine="Log(\"登入中....\")";
parent.__c.LogImpl("745023238","登入中....",0);
 //BA.debugLineNum = 97;BA.debugLine="basicAuth = $\"${txtNo.text}:${txtPassword.text}\"$";
_basicauth = (""+parent.__c.SmartStringFormatter("",(Object)(parent._txtno._gettext /*String*/ ()))+":"+parent.__c.SmartStringFormatter("",(Object)(parent._txtpassword._gettext /*String*/ ()))+"");
 //BA.debugLineNum = 98;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 99;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/login\"$";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/login"),(""));
 //BA.debugLineNum = 102;BA.debugLine="Log($\"basicAuth= Basic ${su.EncodeBase64(basicAut";
parent.__c.LogImpl("745023249",("basicAuth= Basic "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 105;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Basic";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Basic "+_su.EncodeBase64(_basicauth.getBytes("UTF8")));
 //BA.debugLineNum = 106;BA.debugLine="job.GetRequest.SetContentType(\"application/json\")";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/json");
 //BA.debugLineNum = 111;BA.debugLine="Function01.ProgressShow(indLoading,\"\")";
parent._function01._progressshow /*String*/ (parent._indloading,"");
 //BA.debugLineNum = 112;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 13;
return;
case 13:
//C
this.state = 1;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 113;BA.debugLine="Function01.ProgressHide(indLoading)";
parent._function01._progresshide /*String*/ (parent._indloading);
 //BA.debugLineNum = 115;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("745023262","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 116;BA.debugLine="If job.Success Then";
if (true) break;

case 1:
//if
this.state = 12;
if (_job._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 11;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 117;BA.debugLine="Log(job.GetString)";
parent.__c.LogImpl("745023264",_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 118;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4j.objects.collections.JSONParser();
 //BA.debugLineNum = 119;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 120;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 122;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 4:
//if
this.state = 9;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 //BA.debugLineNum = 123;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("745023270",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 125;BA.debugLine="xui.MsgboxAsync(m.Get(\"message\"), \"Info\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToString(_m.Get((Object)("message"))),"Info");
 //BA.debugLineNum = 128;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 130;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("745023277",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 9:
//C
this.state = 12;
;
 //BA.debugLineNum = 134;BA.debugLine="Main.mem_no = txtNo.text";
parent._main._mem_no /*String*/  = parent._txtno._gettext /*String*/ ();
 //BA.debugLineNum = 135;BA.debugLine="Main.token  = m.Get(\"token\")";
parent._main._token /*String*/  = BA.ObjectToString(_m.Get((Object)("token")));
 //BA.debugLineNum = 137;BA.debugLine="Log(\"token= \"&Main.token)";
parent.__c.LogImpl("745023284","token= "+parent._main._token /*String*/ ,0);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 140;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("745023287",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 141;BA.debugLine="xui.MsgboxAsync(LastException, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToString(parent.__c.LastException(ba)),"Error");
 //BA.debugLineNum = 143;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 12:
//C
this.state = -1;
;
 //BA.debugLineNum = 147;BA.debugLine="txtNo.Text = \"\"";
parent._txtno._settext /*String*/ ("");
 //BA.debugLineNum = 148;BA.debugLine="txtPassword.Text = \"\"";
parent._txtpassword._settext /*String*/ ("");
 //BA.debugLineNum = 153;BA.debugLine="B4XPages.ShowPageAndRemovePreviousPages(\"HomePage";
parent._b4xpages._showpageandremovepreviouspages /*String*/ ("HomePage");
 //BA.debugLineNum = 154;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(b4j.example.httpjob _job) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 13;BA.debugLine="Public vHomePage As HomePage";
_vhomepage = new b4j.example.homepage();
 //BA.debugLineNum = 14;BA.debugLine="Public vMemberPage As MemberPage";
_vmemberpage = new b4j.example.memberpage();
 //BA.debugLineNum = 17;BA.debugLine="Public toast As BCToast";
_toast = new b4j.example.bctoast();
 //BA.debugLineNum = 20;BA.debugLine="Public Const PlusChar As String = Chr(0xF067) '+";
_pluschar = BA.ObjectToString(__c.Chr(((int)0xf067)));
 //BA.debugLineNum = 26;BA.debugLine="Private btnLogin As B4XView";
_btnlogin = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Public txtNo As B4XFloatTextField";
_txtno = new b4j.example.b4xfloattextfield();
 //BA.debugLineNum = 28;BA.debugLine="Public txtPassword As B4XFloatTextField";
_txtpassword = new b4j.example.b4xfloattextfield();
 //BA.debugLineNum = 34;BA.debugLine="Private indLoading As B4XLoadingIndicator";
_indloading = new b4j.example.b4xloadingindicator();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 37;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public String  _txtno_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Sub txtNo_TextChanged (Old As String, New As Strin";
 //BA.debugLineNum = 69;BA.debugLine="If New.Length > 0 And txtPassword.text.Length >0";
if (_new.length()>0 && _txtpassword._gettext /*String*/ ().length()>0) { 
 //BA.debugLineNum = 70;BA.debugLine="btnLogin.Enabled = True";
_btnlogin.setEnabled(__c.True);
 }else {
 //BA.debugLineNum = 72;BA.debugLine="btnLogin.Enabled = False";
_btnlogin.setEnabled(__c.False);
 };
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public String  _txtpassword_textchanged(String _old,String _new) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Sub txtPassword_TextChanged (Old As String, New As";
 //BA.debugLineNum = 76;BA.debugLine="If New.Length > 0 And txtNo.text.Length >0 Then";
if (_new.length()>0 && _txtno._gettext /*String*/ ().length()>0) { 
 //BA.debugLineNum = 77;BA.debugLine="btnLogin.Enabled = True";
_btnlogin.setEnabled(__c.True);
 }else {
 //BA.debugLineNum = 79;BA.debugLine="btnLogin.Enabled = False";
_btnlogin.setEnabled(__c.False);
 };
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
