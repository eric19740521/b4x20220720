package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_card{

public static void LS_general(anywheresoftware.b4a.BA ba, javafx.scene.Node parent, anywheresoftware.b4j.objects.LayoutValues lv,
anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale)  throws Exception  {
;
//BA.debugLineNum = 3;BA.debugLine="DDD.CollectViewsData"[Card/General script]
anywheresoftware.b4j.objects.DesignerArgs.callsub(ba, parent, lv, "ddd", "collectviewsdata", width, height, views, new Object[] {});
//BA.debugLineNum = 4;BA.debugLine="AutoScaleAll"[Card/General script]
;

}
}