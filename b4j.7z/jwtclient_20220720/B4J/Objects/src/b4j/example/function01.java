package b4j.example;


import anywheresoftware.b4a.BA;

public class function01 extends Object{
public static function01 mostCurrent = new function01();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.function01", null);
		ba.loadHtSubs(function01.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.function01", ba);
		}
	}
    public static Class<?> getObject() {
		return function01.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.main _main = null;
public static b4j.example.b4xpages _b4xpages = null;
public static b4j.example.b4xcollections _b4xcollections = null;
public static b4j.example.httputils2service _httputils2service = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static String  _progresshide(b4j.example.b4xloadingindicator _obj) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Sub ProgressHide(obj As B4XLoadingIndicator)";
 //BA.debugLineNum = 51;BA.debugLine="obj.Hide";
_obj._hide /*String*/ ();
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public static String  _progressshow(b4j.example.b4xloadingindicator _obj,String _text) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub ProgressShow(obj As B4XLoadingIndicator,text A";
 //BA.debugLineNum = 35;BA.debugLine="Log(\"ProgressShow= \"&text)";
anywheresoftware.b4a.keywords.Common.LogImpl("750987010","ProgressShow= "+_text,0);
 //BA.debugLineNum = 40;BA.debugLine="obj.Show";
_obj._show /*String*/ ();
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public static String  _showtoast(b4j.example.bctoast _toast,anywheresoftware.b4a.objects.B4XViewWrapper _root1,String _message) throws Exception{
int _backgroundcolor = 0;
int _txtcolor = 0;
 //BA.debugLineNum = 12;BA.debugLine="Sub ShowToast(toast As BCToast,Root1 As B4XView, M";
 //BA.debugLineNum = 13;BA.debugLine="Dim BackgroundColor As Int, TxtColor As Int";
_backgroundcolor = 0;
_txtcolor = 0;
 //BA.debugLineNum = 15;BA.debugLine="BackgroundColor = xui.Color_Yellow";
_backgroundcolor = _xui.Color_Yellow;
 //BA.debugLineNum = 16;BA.debugLine="TxtColor = xui.Color_Red";
_txtcolor = _xui.Color_Red;
 //BA.debugLineNum = 18;BA.debugLine="toast.pnl.RemoveViewFromParent";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .RemoveViewFromParent();
 //BA.debugLineNum = 19;BA.debugLine="Root1.AddView(toast.pnl, 0, 0, 0, 0)";
_root1.AddView((javafx.scene.Node)(_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .getObject()),0,0,0,0);
 //BA.debugLineNum = 21;BA.debugLine="toast.DefaultTextColor = TxtColor";
_toast._defaulttextcolor /*int*/  = _txtcolor;
 //BA.debugLineNum = 22;BA.debugLine="toast.pnl.Color = BackgroundColor";
_toast._pnl /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setColor(_backgroundcolor);
 //BA.debugLineNum = 23;BA.debugLine="toast.DurationMs = 1500";
_toast._durationms /*int*/  = (int) (1500);
 //BA.debugLineNum = 25;BA.debugLine="toast.Show($\" ${Message} \"$)";
_toast._show /*void*/ ((" "+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(_message))+" "));
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
}
